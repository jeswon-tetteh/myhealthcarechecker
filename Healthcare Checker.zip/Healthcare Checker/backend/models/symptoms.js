// models/Symptom.js
const mongoose = require("mongoose");

const symptomSchema = new mongoose.Schema({
  symptoms: { type: String, required: true },
  duration: { type: String, required: true },
  frequency: { type: String, required: true },
  worsens: { type: String },
  additional: { type: String },
  conditions: { type: String },
  submittedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Symptom", symptomSchema);
