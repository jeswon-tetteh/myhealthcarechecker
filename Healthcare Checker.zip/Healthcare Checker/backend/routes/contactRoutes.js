// routes/contactRoutes.js
const express = require("express");
const router = express.Router();
const Contact = require("../models/Contact");

// POST: Submit contact form
router.post("/submit-contact", async (req, res) => {
  const { name, email, subject, message } = req.body;

  try {
    // Save contact message to database
    const newContact = new Contact({
      name,
      email,
      subject,
      message,
    });
    await newContact.save();

    res.status(200).json({
      status: "success",
      message: "Thank you for your message! We’ll get back to you soon.",
    });
  } catch (error) {
    console.error("Error submitting contact form:", error);
    res.status(500).json({
      status: "error",
      message: "Failed to send message. Please try again.",
    });
  }
});

module.exports = router;
