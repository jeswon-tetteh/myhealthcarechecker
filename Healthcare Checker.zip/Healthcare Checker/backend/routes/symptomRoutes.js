// routes/symptomRoutes.js
const express = require("express");
const router = express.Router();
const Symptom = require("../models/Symptom");

// POST: Submit symptoms for analysis
router.post("/check-symptoms", async (req, res) => {
  const { symptoms, duration, frequency, worsens, additional, conditions } =
    req.body;

  try {
    // Save submission to database
    const newSymptom = new Symptom({
      symptoms,
      duration,
      frequency,
      worsens,
      additional,
      conditions,
    });
    await newSymptom.save();

    // Mock symptom analysis (replace with real logic/API)
    const mockResponse = {
      status: "success",
      message:
        "Symptoms received. Please consult a healthcare professional for a proper diagnosis.",
      details: {
        primarySymptoms: symptoms,
        duration,
        frequency,
        possibleConditions: ["Condition A", "Condition B"], // Placeholder
      },
    };

    res.status(200).json(mockResponse);
  } catch (error) {
    console.error("Error processing symptoms:", error);
    res.status(500).json({
      status: "error",
      message: "Failed to process symptoms. Please try again.",
    });
  }
});

module.exports = router;
